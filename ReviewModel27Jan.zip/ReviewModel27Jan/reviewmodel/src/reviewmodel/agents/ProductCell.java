package reviewmodel.agents;

import java.util.ArrayList;
import java.util.List;

import repast.simphony.engine.schedule.ScheduledMethod;
import repast.simphony.random.RandomHelper;
import repast.simphony.util.ContextUtils;
import repast.simphony.valueLayer.GridValueLayer;
import reviewmodel.common.Constants;

public class ProductCell {

	/** Maximum product production rate is initialized to <code>0.01</code>. */
	private static final double maximumProductProductionRate = 0.01;
	/**
	 * Represents the actual product availability at this cell, initialized to
	 * <code>0.0</code>.
	 */
	private double productAvailability = 0.0;
	public double rating = 0.0;
	/** Location of this cell at the grid. */
	private final int x, y;
	
	public ProductCell(final int x, final int y) {
		if (x < 0) {
			throw new IllegalArgumentException(String.format(
					"Coordinate x = %d < 0.", x));
		}

		if (y < 0) {
			throw new IllegalArgumentException(String.format(
					"Coordinate y = %d < 0.", y));
		}

		this.x = x;
		this.y = y;
		this.rating = rating;
	}

	/**
	 * Returns the current product availability of this cell.
	 * 
	 * @return the <code>productAvailability</code> of the cell; <i>a non-negative
	 *         productRandValue</i>
	 */
	public double getProductAvailability() {
		return productAvailability;
	}
	
	public double getRating() {
		return rating;
	}
	/**
	 * Each time step, product availability is increased by product production. Product
	 * production is a random floating point number between zero and the maximum
	 * product production.
	 * 
	 * <p>
	 * Product production is scheduled before agent actions.
	 * </p>
	 */
	@ScheduledMethod(start = 1, interval = 1, priority = 1)
	public void makeProduct() {
		productAvailability += RandomHelper.nextDoubleFromTo(0.0,
				maximumProductProductionRate);
 
		rating += RandomHelper.nextDoubleFromTo(Constants.REVIEWER_LOWEST_MARK,
				                 Constants.REVIEWER_HIGHEST_MARK);
		
		final GridValueLayer productValueLayer = (GridValueLayer) ContextUtils
				.getContext(this).getValueLayer(Constants.PRODUCT_VALUE_LAYER_ID);

		if (null == productValueLayer) {
			throw new IllegalStateException(
					"Cannot locate product productRandValue layer with ID="
							+ Constants.PRODUCT_VALUE_LAYER_ID + ".");
		}

		productValueLayer.set(getProductAvailability(), x, y);
		productValueLayer.set(getRating(), x, y);
	}

	/**
	 * A {@link Reviewer} agent can buy product of the cell on which it is located
	 * at.
	 * 
	 * @param buyProduct
	 *            product bought by the caller agent from this cell; <i>must be
	 *            non-negative and below the current
	 *            <code>productAvailability</code></i>
	 */
	public void productBought(final double buyProduct) {
		if (buyProduct < 0.0) {
			throw new IllegalArgumentException(String.format(
					"buyProduct = %f < 0.0", buyProduct));
		}

		if (buyProduct > productAvailability) {
			throw new IllegalArgumentException(String.format(
					"buyProduct = %f > productAvailability = %f", buyProduct,
					productAvailability));
		}

		productAvailability -= buyProduct;
	}
	public double ratingGiven(double rate) {
		
		Reviewer award = new Reviewer();
		rating = award.getRate();
		List<Double> list = new ArrayList<Double>();
		
		/*for (double i = 0.0; i<list.size();i++) {
			list.add(rating);
		System.out.println(list);
		System.out.println(rating);
		}*/
		return rating;
	}
	 @Override
	 public String toString() {
			// Override default Java implementation just to have a nicer
			// representation
			return String.format(
					"ProductCell @ location (%d, %d), productAvailability=%f", x, y,
					productAvailability);
	 }
 }
