package reviewmodel.output;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;

import repast.simphony.context.Context;
import repast.simphony.engine.environment.RunEnvironment;
import repast.simphony.engine.schedule.ScheduleParameters;
import repast.simphony.engine.schedule.ScheduledMethod;
import repast.simphony.parameter.Parameters;
import repast.simphony.util.ContextUtils;
import reviewmodel.agents.PositiveReviewer;
import reviewmodel.agents.ProductCell;
import reviewmodel.agents.Reviewer;
import reviewmodel.common.Constants;

public class CoverageCounter {
	
	public double productRandValue, score, reviewRandAver, 
	productRandTotalAver, reviewerRandTotalAver, colllectRate,
	reviewerPosRating,posReviewCount, productTotalRandAver;
	public double productCellRandRating =0.0;
	public double reviewerRandRating =0.0;
	public double reviewCount = 0.0;
	public double reviewerRandRateTotal = 0.0;
	public double reviewerPosRateTotal = 0.0;
	public double productRandRateTotal = 0.0;
	public String reviewToString, reviewPosToString,reviewLocation;
	public String pCellToString;
	public double randTotalReviews, posTotalReview;
	public double productRandAver,productCount, reviewerPosTotalAver,reviewerPosAver;
	
    DecimalFormat df = new DecimalFormat("#.00");
    String newline = System.getProperty("line.separator");
    final Parameters parameters = RunEnvironment.getInstance()
            .getParameters();
    
	@ScheduledMethod(start=1, interval=1, priority=ScheduleParameters.LAST_PRIORITY)
	public void step(){
		updateRating();
	}
	
	public void updateRating() {
		
		Context<?> context = ContextUtils.getContext(this);
		 List<Double> rateCollection = new ArrayList<Double>();
		 List<Double> posRateCollection = new ArrayList<Double>();
		 List<Double> productRateCollection = new ArrayList<Double>();
		Object[] objs = context.toArray();
		
		for (Object obj : objs) {
			if (obj instanceof ProductCell) {
				final ProductCell cell = (ProductCell) obj;
				 productRandValue = cell.getRating();
				 score = cell.ratingGiven(productCellRandRating);	
				 pCellToString = cell.toString();
				 productCount++;
			/*((ProductCell) obj).ratingGiven(productCellRandRating);*/
			}
			else if(obj instanceof Reviewer) {
				Reviewer rw = (Reviewer)obj;
				reviewerRandRating = rw.getRate();
				reviewToString = rw.toString();
				reviewLocation = rw.location();
				reviewCount++;
			}else if(obj instanceof PositiveReviewer){
				PositiveReviewer  pw = (PositiveReviewer)obj;
				reviewerPosRating = pw.getRate();
				reviewPosToString = pw.toString();
				posReviewCount ++;
			}
		}
		
		productRateCollection.add(productRandValue);
		int j = productRateCollection.size();
		for (int i = 0; i< j; i++) {
			productRandRateTotal += productRateCollection.get(i);
		}
		productTotalRandAver = productRandRateTotal/productRateCollection.size();
		productRandAver = productTotalRandAver/randTotalReviews;
		
		final int reviewerCount = ((Integer) parameters
                .getValue(Constants.PARAMETER_ID_REVIEWER_COUNT)).intValue();
		randTotalReviews = reviewCount/ reviewerCount;
		 rateCollection.add(reviewerRandRating);
		 int n = rateCollection.size();
		 
			for(int i = 0; i < n; i++){
			 reviewerRandRateTotal += rateCollection.get(i);
		}
			reviewerRandTotalAver = reviewerRandRateTotal/rateCollection.size();
			reviewRandAver = reviewerRandTotalAver/randTotalReviews;
		
		/*	final int posReviewCount = ((Integer) parameters
	                .getValue(Constants.PARAMETER_ID_POSITIVE_REVIEWER_COUNT)).intValue();
			posTotalReview = reviewCount/posReviewCount;
			posRateCollection.add(reviewerPosRating);
			int b =posRateCollection.size();
			for (int i=0; i<b; i++)
			{
				reviewerPosRateTotal = posRateCollection.get(b);
			}
			reviewerPosTotalAver = reviewerPosRateTotal/posRateCollection.size();
			reviewerPosAver = reviewerPosTotalAver/randTotalReviews;*/
			
		System.out.println("************************************************************"+newline);	
		System.out.println("              "+randTotalReviews+ " is number of reviews" );
		System.out.println("Product Cell's own given random productRandValue at one location : " + df.format(productRandValue));  /*in getRating*/
		System.out.println("Average Random value : "+ df.format(productRandAver)+" Product Cells total random product value : " + df.format(productRandRateTotal));
		System.out.println("Product cell toString " + pCellToString);
        	/*	System.out.println("@@ProductCell rating given " + df.format(score));*/
	/*	System.out.println(" �� Reviewer toString"+ reviewToString);*/
	/*	System.out.println("Reviewer latest random rating at given location " + df.format(reviewerRandRating)); -- updateRating*/
		System.out.println("Average of all reviewer's rating : "+ df.format(reviewerRandTotalAver));
		System.out.println("Random reviewer average review rating  : "+df.format(reviewRandAver)); 
		/*	System.out.println("************************************************************");	reviewRandAver = reviewerRandTotalAver/randTotalReviews;*/
	    System.out.println("Positive reviewer rating : "+ df.format(reviewerPosRating)+ " <> pos review count" + posReviewCount);
System.out.println("Product count,"  +productCount+ " Random reviewCount, "+ randTotalReviews +" Positive ReviewCount, "+ posReviewCount);
	System.out.println("::::::::::: "+ reviewLocation);
/*	System.out.println("Positive Average Rating : "+reviewerPosAver);*/
	}

}
