package reviewmodel.common;

public final class Constants {

	/** The root <code>Context</code> ID. */
	public static final String CONTEXT_ID = "reviewmodel";

	/** The <code>Space</code> ID. */
	public static final String SPACE_ID = "space";

	/** The <code>Grid</code> ID. */
	public static final String GRID_ID = "grid";

	/** The first model specified a two-dimensional grid <code>100 * 100</code>. */
	public static final int GRID_SIZE = 100;

	/**
	 * The first model specified to create <code>100</code> {@link REVIEWER} agents.
	 */
/*	public static final int REVIEWER_COUNT = 36;*/
  /**
   * reviewer count parameter now changable in the gui
   */
	  public static final String PARAMETER_ID_REVIEWER_COUNT = "reviewerCount";
/**
 * positive reviewer count parameter now changeable in GUI
 */
	  public static final String PARAMETER_ID_POSITIVE_REVIEWER_COUNT = "positiveReviewerCount";
	  
	  /*
	   * negative reviewer count parameter now changeable in GUI
	   */
	  public static final String PARAMETER_ID_NEGATIVE_REVIEWER_COUNT = "negativeReviewerCount";
	/**
	 * the lowest rating for a product
	 */
	public static final double REVIEWER_LOWEST_MARK = 1.0;
	
	/**
	 * the highest rating for a product
	 */
	public static final double REVIEWER_HIGHEST_MARK = 10.0;
	
	/**
	 * The first model specified an agent vision range of <code>4 * 4</code>
	 * cells.
	 */
	public static final int REVIEWER_VISION_RANGE = 30;

	/** A REVIEWER grows by a fixed amount of size in each time step. */
	public static final double REVIEWER_GROWTH_RATE = 1.0;

	public static final String PRODUCT_VALUE_LAYER_ID = "productValueLayer";
	/**
	 * Hidden constructor to ensure no instances are created.
	 */
	private Constants() {
		;
	}

}
