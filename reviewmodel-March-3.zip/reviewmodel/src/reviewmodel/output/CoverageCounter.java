package reviewmodel.output;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.Multimap;

import repast.simphony.context.Context;
import repast.simphony.engine.environment.RunEnvironment;
import repast.simphony.engine.schedule.ScheduleParameters;
import repast.simphony.engine.schedule.ScheduledMethod;
import repast.simphony.parameter.Parameters;
import repast.simphony.space.grid.GridPoint;
import repast.simphony.util.ContextUtils;
import reviewmodel.agents.NegativeReviewer;
import reviewmodel.agents.PositiveReviewer;
import reviewmodel.agents.ProductCell;
import reviewmodel.agents.Reviewer;
import reviewmodel.agents.Watcher;
import reviewmodel.common.Constants;
import reviewmodel.common.SMUtils;

public class CoverageCounter {

	public double productRandValue, reviewRandAver, reviewDiff, negDiff,
			posDiff, productRandTotalAver, reviewerRandTotalAver, colllectRate,
			negReviewCount, productTotalRandAver, rateAwarded, wtrLowRate,
			wtrHighRate;
	ProductCell reviewValue, postiveValue, negValue, globalProdRate, irwin;
	public double productCellRandRating = 0.0;
	public double reviewerRandRating = 0.0;
	public double reviewerPosRating = 0.0;
	public double reviewerNegRating = 0.0;
	public double reviewCount = 0.0;
	public double posReviewCount = 0.0;
	public double reviewerRandRateTotal = 0.0;
	public double reviewerPosRateTotal = 0.0;
	public double reviewerNegRateTotal = 0.0;
	public double productRandRateTotal = 0.0;
	public String reviewToString, reviewPosToString, negReviewToString,
			reviewLocation, reviewId, negId, posId, wRaterStr, wRaterLocale,
			wtrLowName, wtrHighName, wtrFoundHighName, wtrFoundLowName;

	Map<String, Double> ratingScheme;
/*	Map<String, Double> reviewersRatingsStored;*/
	Map<String, Double> allRatings;
	Multimap<Double, Double> reviewPastArray;
	public String pCellToString, reviewFormatId;
	public double timeStep, posTimeStep, negTimeStep;
	public double productRandAver, productCount, reviewerPosTotal,
			reviewerPosAver, reviewerNegTotal, reviewerNegAver;
	Multimap<String, Double> myMultimap = ArrayListMultimap.create();
	Multimap<String, Double> readPrevMultimap = ArrayListMultimap.create();
	Multimap<String, Multimap<String, Double>> anotherMultimap = ArrayListMultimap
			.create();
	Map<String, Double> watcherHashmap = new HashMap<String, Double>();
	Map<String, Double> watcherAveHashmap = new HashMap<String, Double>();
	String newline = System.getProperty("line.separator");

	public Multimap<String, Double> getMyMultimap() {
		return myMultimap;
	}

	public void setMyMultimap(Multimap<String, Double> myMultimap) {
		this.myMultimap = myMultimap;
	}

	final Parameters parameters = RunEnvironment.getInstance().getParameters();

	@ScheduledMethod(start = 1, interval = 1, priority = ScheduleParameters.LAST_PRIORITY)
	public void step() {
		updateRating();
	}

	public void updateRating() {

		Context<?> context = ContextUtils.getContext(this);
		List<Double> rateCollection = new ArrayList<Double>();
		List<Double> posRateCollection = new ArrayList<Double>();
		List<Double> productRateCollection = new ArrayList<Double>();
		List<Double> negRateCollection = new ArrayList<Double>();
		Object[] objs = context.toArray();

		for (Object obj : objs) {
			if (obj instanceof ProductCell) {
				final ProductCell cell = (ProductCell) obj;
			//	productRandValue = cell.getRating();
				pCellToString = cell.toString();
				ratingScheme = cell.toRatingSystem();
				productCount++;

			} else if (obj instanceof Reviewer) {
				Reviewer rw = (Reviewer) obj;
				// reviewerRandRating = rw.getRate();
				// reviewerRandRating = SMUtils.round(reviewerRandRating, 2);
				reviewToString = rw.toString();
				reviewLocation = rw.location();
				reviewId = rw.getID();
				reviewDiff = rw.getDifference();
				myMultimap.put(reviewId, reviewDiff);
				reviewCount++;

				// reviewDiff = SMUtils.round(reviewDiff, 2);
				// reviewPastArray = rw.getPrevious();
				// reviewPastArray = SMUtils.round(reviewPastArray, 2);
				// reviewFormatId = df.format(reviewId);

				// anotherMultimap.put(reviewLocation, myMultimap);
				// reviewValue = rw.productRate();
				// reviewersRatingsStored = rw.getReviewersStoredRatings();
				// globalProdRate = rw.globalProdRating();

			} else if (obj instanceof NegativeReviewer) {
				NegativeReviewer nr = (NegativeReviewer) obj;
				negId = nr.getID();
				negDiff = nr.getDifference();
				myMultimap.put(negId, negDiff);
				negReviewCount++;
				// reviewerNegRating = nr.getRate();
				// reviewerNegRating = SMUtils.round(reviewerNegRating, 2);
				// negReviewToString = nr.toString();
				// negValue = nr.productRate();
			} else if (obj instanceof PositiveReviewer) {
				PositiveReviewer pr = (PositiveReviewer) obj;
				posId = pr.getID();
				posDiff = pr.getDifference();
				myMultimap.put(posId, posDiff);
				posReviewCount++;
				// reviewerPosRating = pr.getRate();
				// reviewerPosRating = SMUtils.round(reviewerPosRating, 2);
				// reviewPosToString = pr.toString();
				// postiveValue = pr.productRate();

			} else if (obj instanceof Watcher) {
				Watcher wRater = (Watcher) obj;
				wRaterStr = wRater.toString();
				wRaterLocale = wRater.location();
				watcherHashmap = wRater.readReview();
				watcherAveHashmap = wRater.calculateAverage();
				wtrLowRate = wRater.lowest();
				wtrLowName = wRater.getLowestName();
				wtrHighRate = wRater.highest();
				wtrHighName = wRater.getHighestName();
				wtrFoundLowName = wRater.readPastLowReviews();
				wtrFoundHighName = wRater.readPastHighReviews();
				readPrevMultimap = wRater.readPastRatings();
			}
		}

		anotherMultimap.put(reviewLocation, myMultimap);

		productRateCollection.add(productRandValue);
		int j = productRateCollection.size();
		for (int i = 0; i < j; i++) {
			productRandRateTotal += productRateCollection.get(i);
		}
		productTotalRandAver = productRandRateTotal
				/ productRateCollection.size();
		productRandAver = productTotalRandAver / timeStep;

		final int reviewerCount = ((Integer) parameters
				.getValue(Constants.PARAMETER_ID_REVIEWER_COUNT)).intValue();
		timeStep = reviewCount / reviewerCount;
		rateCollection.add(reviewerRandRating);
		int n = rateCollection.size();

		for (int i = 0; i < n; i++) {
			reviewerRandRateTotal += rateCollection.get(i);
		}
		reviewerRandTotalAver = reviewerRandRateTotal / rateCollection.size();
		reviewRandAver = reviewerRandTotalAver / timeStep;

		final int posReviewerCount = ((Integer) parameters
				.getValue(Constants.PARAMETER_ID_POSITIVE_REVIEWER_COUNT))
				.intValue();
		posTimeStep = posReviewCount / posReviewerCount;
		posRateCollection.add(reviewerPosRating);
		int b = posRateCollection.size();
		for (int i = 0; i < b; i++) {
			reviewerPosRateTotal += posRateCollection.get(i);
		}
		reviewerPosTotal = reviewerPosRateTotal / posRateCollection.size();
		reviewerPosAver = reviewerPosTotal / posTimeStep;

		final int negReviewerCount = ((Integer) parameters
				.getValue(Constants.PARAMETER_ID_NEGATIVE_REVIEWER_COUNT))
				.intValue();
		negTimeStep = negReviewCount / negReviewerCount;
		negRateCollection.add(reviewerNegRating);
		int f = negRateCollection.size();
		for (int i = 0; i < f; i++) {
			reviewerNegRateTotal += negRateCollection.get(i);
		}
		reviewerNegTotal = reviewerNegRateTotal / negRateCollection.size();
		reviewerNegAver = reviewerNegTotal / negTimeStep;

		System.out.println(newline);
		System.out
				.println("************************************************************");
		System.out.println("              " + timeStep
				+ " is number of reviews");
		/*
		 * System.out.println(
		 * "Product Cell's own given random productRandValue at one location : "
		 * + df.format(productRandValue)); in getRating
		 * System.out.println("Average Random value : "+
		 * df.format(productRandAver
		 * )+" Product Cells total random product value : " +
		 * df.format(productRandRateTotal));
		 */// System.out.println("Product cell toString " + pCellToString +
			// "  rateGiven for cell	" + rateAwarded + ";;;;;;;	" +rateGiven);
		/* System.out.println("@@ProductCell rating given " + df.format(score)); */
		/* System.out.println(" �� Reviewer toString"+ reviewToString); */
		/*
		 * System.out.println("Reviewer latest random rating at given location "
		 * + df.format(reviewerRandRating)); -- updateRating
		 */
		/*
		 * System.out.println("Average of all reviewer's rating : "+
		 * df.format(reviewerRandTotalAver));
		 */// System.out.println("Random reviewer average review rating  : "+df.format(reviewRandAver));
		/*
		 * System.out.println(
		 * "************************************************************");
		 * reviewRandAver = reviewerRandTotalAver/timeStep;
		 */

		/*
		 * System.out.println("Positive reviewer rating : "+
		 * df.format(reviewerPosRating)+ " <> pos review count" +
		 * posReviewCount);
		 * 
		 * System.out.println("Product count," +productCount+
		 * " Random reviewCount, "+ timeStep +" Positive ReviewCount, "+
		 * posReviewCount);
		 * 
		 * System.out.println("Positive Average Rating : "+reviewerPosAver);
		 */
		System.out.println(" This is the reviewer's product's own rateValue "
				+ reviewValue );
		System.out.println(" this is the watcher location" + wRaterLocale
				+ " the is readReivew methodin watcher " + watcherHashmap
				+ "|| " + wtrLowName + "/" + wtrLowRate + "|| " + wtrHighName
				+ "/" + wtrHighRate);
		System.out.println(" Watcher method readPastLowReviews()"
				+ wtrFoundLowName);
		System.out.println(" Watcher method readPastHighReviews()"
				+ wtrFoundHighName);
		System.out.println("Watcher average reviews " + watcherAveHashmap);
	/*	System.out.println("PreviousRating in CC " + readPrevMultimap);*/
		/*
		 * System.out .println(":::: " + reviewLocation); //
		 * System.out.println(newline); System.out
		 * .println(" This is the positive reviewer's product's own rateValue "
		 * + postiveValue); System.out .println("**** " + reviewPosToString); //
		 * System.out.println(newline); System.out
		 * .println(" This is the negative reviewer's product's own rateValue "
		 * + negValue); System.out .println("---- " + negReviewToString);
		 */
		/* */
		/*
		 * working just commented out to try Reviewer hashmap 19.02 11.30pm
		 * System.out.println("Product Cell's average review rating  : " +
		 * df.format(productRandAver));
		 * System.out.println("Reviewer average review rating  : " +
		 * df.format(reviewRandAver));
		 * System.out.println("Positive reviewer average review rating : " +
		 * df.format(reviewerPosAver));
		 * System.out.println("Negative reviewer average review rating : " +
		 * df.format(reviewerNegAver)); System.out.println("Product count : " +
		 * productCount + " Total Review Count " + reviewCount +
		 * " Positive Review Count : " + posReviewCount +
		 * " Negative Review Count : " + negReviewCount);
		 * System.out.println("Review Time Step, " + timeStep +
		 * " PosTimeStep : " + posTimeStep + " NegTimeStep " + negTimeStep);
		 */
		// String previous = df.format(pastArray);
		// System.out.println("past values of " + reviewId +
		// " : "+reviewPastArray );
		// System.out.println("multiMap	\n"+myMultimap );
		// System.out.println("multiMap of multiMaps	\n"+anotherMultimap );

		/*
		 * Set<String> keys = anotherMultimap.keySet(); for (String key : keys)
		 * { System.out.println("Key = " + key); System.out.println("Values = "
		 * + anotherMultimap.get(key) + "\n"); }
		 */

		Set<String> keys = myMultimap.keySet();
		for (String key : keys) {
			System.out.println("Key = " + key);
			System.out.println("Diff in Values = " + myMultimap.get(key) + "\n");
		}

		//System.out.println("<< " + ratingScheme);
		// System.out.println("Reviewer to String"+ reviewToString);
		
		;
	}

}
