package reviewmodel.common;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import repast.simphony.query.space.grid.GridCell;
import repast.simphony.random.RandomHelper;
import repast.simphony.space.grid.Grid;
import repast.simphony.util.ContextUtils;


public final strictfp class SMUtils {

	public static <T> List<GridCell<T>> getFreeGridCells(
			final List<GridCell<T>> neighborhood) {
		if (null == neighborhood) {
			throw new IllegalArgumentException(
					"Parameter neighborhood cannot be null.");
		}

		final ArrayList<GridCell<T>> ret = new ArrayList<GridCell<T>>();

		for (final GridCell<T> act : neighborhood) {
			if (0 == act.size()) {
				ret.add(act);
			}
		}

		return ret;
	}


	public static <T> T randomElementOf(final List<T> list) {
		if (null == list) {
			throw new IllegalArgumentException("Parameter list cannot be null.");
		}

		if (list.isEmpty()) {
			throw new IllegalArgumentException(
					"Cannot return a random element from an empty list.");
		}

		return list.get(RandomHelper.nextIntFromTo(0, list.size() - 1));
	}
	
	public static <T> void addAll(Collection<T> collection, Iterator<T> iterator) {
	    while (iterator.hasNext()) {
	        collection.add(iterator.next());
	    }
	}

	/**
	 * Returns a reference to the grid on which the specified agent is located
	 * at.
	 * 
	 * <p>
	 * It was a {@link Reviewer} level agent function, but was generalised because in
	 *  we have multiple agent instances requiring this
	 * functionality.
	 * </p>
	 * 
	 * @param o
	 *            an object to find in the contexts and return its grid
	 *            projection; <i>cannot be <code>null</code></i>
	 * @return the <code>Grid</code> on which the agent is located; 
	 *             <i>cannot be
	 *         <code>null</code></i>
	 * 
	 */
	
	public static Grid<Object> getGrid(final Object o) {
	    @SuppressWarnings("unchecked")
	    final Grid<Object> grid = (Grid<Object>) ContextUtils.getContext(o)
	            .getProjection(Constants.GRID_ID);
	    if (null == grid) {
			throw new IllegalStateException("Cannot locate grid in context.");
		}

		return grid;
	}
	/*
	 * method to round doubles to n decimal place
	 */
	public static double round(double valueToRound, int noOfDeciPlaces){
		double a = valueToRound;
		double temp = Math.pow(10.0, noOfDeciPlaces);
		a *= temp;
		a = Math.round(a);
		
		return (a / (double)temp);
		}
	
	private SMUtils() {
		;
	}

}
