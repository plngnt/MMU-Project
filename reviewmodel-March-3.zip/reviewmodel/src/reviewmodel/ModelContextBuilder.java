package reviewmodel;

import repast.simphony.context.Context;
import repast.simphony.context.DefaultContext;
import repast.simphony.context.space.continuous.ContinuousSpaceFactoryFinder;
import repast.simphony.context.space.grid.GridFactoryFinder;
import repast.simphony.dataLoader.ContextBuilder;
import repast.simphony.engine.environment.RunEnvironment;
import repast.simphony.parameter.Parameters;
import repast.simphony.space.continuous.ContinuousSpace;
import repast.simphony.space.continuous.NdPoint;
import repast.simphony.space.continuous.RandomCartesianAdder;
import repast.simphony.space.grid.Grid;
import repast.simphony.space.grid.GridBuilderParameters;
import repast.simphony.space.grid.SimpleGridAdder;
import repast.simphony.space.grid.WrapAroundBorders;
import repast.simphony.valueLayer.GridValueLayer;
import reviewmodel.agents.NegativeReviewer;
import reviewmodel.agents.PositiveReviewer;
import reviewmodel.agents.ProductCell;
import reviewmodel.agents.Reviewer;
import reviewmodel.agents.Watcher;
import reviewmodel.common.Constants;
import reviewmodel.output.CoverageCounter;


public class ModelContextBuilder extends DefaultContext<Object> implements
		ContextBuilder<Object> {

	@Override
	public Context<Object> build(final Context<Object> context) {

		// Set a specified context ID
		context.setId(Constants.CONTEXT_ID);
		// get environment variables from GUI
		final Parameters parameters = RunEnvironment.getInstance()
				.getParameters();
		int gridWidth = (Integer) parameters.getValue("gridWidth");
		int gridHeight = (Integer) parameters.getValue("gridHeight");

		// Create a toridal space with random positioning with the specified
		// dimensions
		final ContinuousSpace<Object> space = ContinuousSpaceFactoryFinder
				.createContinuousSpaceFactory(null)
				.createContinuousSpace(
						Constants.SPACE_ID,
						context,
						new RandomCartesianAdder<Object>(),
						new repast.simphony.space.continuous.WrapAroundBorders(),
						gridWidth, gridHeight);

		// Create the default grid to display where agents move
		final Grid<Object> grid = GridFactoryFinder
				.createGridFactory(null)
				.createGrid(
						Constants.GRID_ID,
						context,
						new GridBuilderParameters<Object>(
								new repast.simphony.space.grid.WrapAroundBorders(),
								// This is a simple implementation of an adder
								// that doesn't perform any action
								new SimpleGridAdder<Object>(),
								// Each cell in the grid is multi-occupancy
								true,
								// Size of the grid 
								gridWidth, gridHeight));

		// Create the specified number of reviewer agents and assign them to the
		// space and the grid
		final int reviewerCount = ((Integer) parameters
				.getValue(Constants.PARAMETER_ID_REVIEWER_COUNT)).intValue();

		// Parameter usage I: Parameter is declared on the graphical user
		// interface
		for (int i = 0; i < reviewerCount; ++i) {
			final Reviewer reviewer = new Reviewer();
			context.add(reviewer);
			final NdPoint point = space.getLocation(reviewer);
			grid.moveTo(reviewer, (int) point.getX(), (int) point.getY());
		}
		// Same routine as above for Positive reviewers
		final int positiveReviewerCount = ((Integer) parameters
				.getValue(Constants.PARAMETER_ID_POSITIVE_REVIEWER_COUNT))
				.intValue();
		
		// Parameter usage II: Parameter is declared on the graphical user
		// interface
		for (int i = 0; i < positiveReviewerCount; ++i) {
			final PositiveReviewer positiveReviewer = new PositiveReviewer();
			context.add(positiveReviewer);
			final NdPoint point = space.getLocation(positiveReviewer);
			grid.moveTo(positiveReviewer, (int) point.getX(),
					(int) point.getY());
		}

		// Same routine as above for Negative reviewers
		final int negativeReviewerCount = ((Integer) parameters
				.getValue(Constants.PARAMETER_ID_NEGATIVE_REVIEWER_COUNT))
				.intValue();
		// Parameter usage III: Parameter is declared on the graphical user
		// interface
		for (int i = 0; i < negativeReviewerCount; ++i) {
			final NegativeReviewer negativeReviewer = new NegativeReviewer();
			context.add(negativeReviewer);
			final NdPoint point = space.getLocation(negativeReviewer);
			grid.moveTo(negativeReviewer, (int) point.getX(),
					(int) point.getY());
		}
		// Same routine as above for Watcher
				final int watcherCount = ((Integer) parameters
						.getValue(Constants.PARAMETER_ID_WATCHER_COUNT))
						.intValue();
				// Parameter usage IV: Parameter is declared on the graphical user
				// interface
				for (int i = 0; i < watcherCount; ++i) {
					final Watcher watcher = new Watcher();
					context.add(watcher);
					final NdPoint point = space.getLocation(watcher);
					grid.moveTo(watcher, (int) point.getX(),
							(int) point.getY());
				}
		// Create a background layer for the displayed grid that represents the
		// available product amount
		final GridValueLayer productValueLayer = new GridValueLayer(
				Constants.PRODUCT_VALUE_LAYER_ID, // Access layer through
													// context
				true, // Densely populated
				new WrapAroundBorders(), // Toric world
				// Size of the grid 
				gridWidth, gridHeight);

		context.addValueLayer(productValueLayer);

		// Fill up the context with cells, and set the initial product values for
		// the new layer. Also add them to the created grid.
		for (int i = 0; i < gridWidth; ++i) {
			for (int j = 0; j < gridHeight; ++j) {
				final ProductCell cell = new ProductCell(i, j);
				context.add(cell); // First add it to the context
				grid.moveTo(cell, i, j);
				productValueLayer.set(cell.getProductAvailability(), i, j);
				//productValueLayer.set(cell.getRating(), i,j);
			}
		}
		
	
		final GridValueLayer productRatingLayer = new GridValueLayer(
				Constants.PRODUCT_RATING_LAYER_ID, // Access layer through
				// context
				true, // Densely populated
				new WrapAroundBorders(), // Toric world
				// Size of the grid 
				gridWidth, gridHeight);

		context.addValueLayer(productRatingLayer);
	
		for (int i = 0; i < gridWidth; ++i) {
			for (int j = 0; j < gridHeight; ++j) {
				final ProductCell cell = new ProductCell(i, j);
				productRatingLayer.set(cell.fixedProductRating(),i,j);
			}
		}
		
		// Add CoverageCounter for console output of all Reviewers and Watchers actions
		context.add(new CoverageCounter());
		
		return context;
	}

}
