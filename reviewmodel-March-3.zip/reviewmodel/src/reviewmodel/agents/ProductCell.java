package reviewmodel.agents;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;

import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.Multimap;

import repast.simphony.engine.schedule.ScheduledMethod;
import repast.simphony.random.RandomHelper;
import repast.simphony.space.grid.Grid;
import repast.simphony.space.grid.GridPoint;
import repast.simphony.util.ContextUtils;
import repast.simphony.valueLayer.GridValueLayer;
import reviewmodel.common.Constants;
import reviewmodel.common.SMUtils;

public class ProductCell {

	/* Maximum product production rate is initialised to <code>0.01</code>. */
	private static final double maximumProductProductionRate = 0.1;
	/*
	 * Represents the actual product availability at this cell, initialised to
	 * <code>0.0</code>.
	 */
	
	private double productCellFixedRating = 0.0;
	private double productAvailability = 0.0;
	private double rating = 0.0;
	private double value;
	private double cellValue;
	private double lowest, highest, rangeBetween;
	private String name, rvrLoc;
	ProductCell pcRating;
	List<Double> rateAwarded = new ArrayList<Double>();
	//Map<String, Double> ratingSystem = new HashMap<String, Double>();
	Map<String, Double> fullRatingSystem = new HashMap<String, Double>();
	Map<String, Double> diffInRatingSystem = new HashMap<String, Double>();

	
	DecimalFormat df = new DecimalFormat("#0.00");
	private final int x, y;

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getValue() {
		return value;
	}
	public void setValue(double value) {
		this.value = value;
	}
	public double getLowest() {
		return lowest;
	}
	public void setLowest(double lowest) {
		this.lowest = lowest;
	}
	public double getHighest() {
		return highest;
	}
	public void setHighest(double highest) {
		this.highest = highest;
	}
/*	public Map<String, Double> getDiffInRatingSystem() {
		return diffInRatingSystem;
	}
	*/
	public Map<String, Double> getFullRatingSystem() {
		return fullRatingSystem;
	}
	public ProductCell(final int x, final int y) {
		if (x < 0) {
			throw new IllegalArgumentException(String.format(
					"Coordinate x = %d < 0.", x));
		}
		if (y < 0) {
			throw new IllegalArgumentException(String.format(
					"Coordinate y = %d < 0.", y));
		}
		this.x = x;
		this.y = y;
		
	}
	/*
	 * Returns the current product availability of this cell.
	 * 
	 * @return the <code>productAvailability</code> of the cell; <i>a
	 *         non-negative productRandValue</i>
	 */
	public double getProductAvailability() {
		return productAvailability;
	}
	public double getRating() {
		return rating;
	}
	/* Code from emma  to use as rating for indivd cells  bring up NaN for reviewer's rating
	Collection<Double>values = ratingSystem.values();
	int i = 0;
	double n = 0;
	for(Double v : values) {
		i++;
		n += v.doubleValue();
	}
	 return n/i;*/
	/*
	 * Each time step, product availability is increased by product production.
	 * Product production is a random floating point number between zero and the
	 * maximum product production.
	 * 
	 * <p>
	 * Product production is scheduled before agent actions.
	 * </p>
	 */
	@ScheduledMethod(start = 1, interval = 1, priority = 1)
	public void makeProduct() {
		productAvailability += RandomHelper.nextDoubleFromTo(0.0,
				maximumProductProductionRate);

		rating = RandomHelper.nextDoubleFromTo(Constants.REVIEWER_LOWEST_MARK,
				Constants.REVIEWER_HIGHEST_MARK);

		final GridValueLayer productValueLayer = (GridValueLayer) ContextUtils
				.getContext(this).getValueLayer(
						Constants.PRODUCT_VALUE_LAYER_ID);

		if (null == productValueLayer) {
			throw new IllegalStateException(
					"Cannot locate product productRandValue layer with ID="
							+ Constants.PRODUCT_VALUE_LAYER_ID + ".");
		}
		final GridValueLayer productRatingLayer = (GridValueLayer) ContextUtils
				.getContext(this).getValueLayer(
						Constants.PRODUCT_RATING_LAYER_ID);

		if (null == productRatingLayer) {
			throw new IllegalStateException(
					"Cannot locate product productRatingValue layer with ID="
							+ Constants.PRODUCT_RATING_LAYER_ID + ".");
		}
		productValueLayer.set(getProductAvailability(), x, y);
		productValueLayer.set(getRating(), x, y);
		 cellValue = productRatingLayer.get(x,y);
	}  
	/*
	 * A {@link Reviewer} agent can buy product of the cell on which it is
	 * located at.
	 * 
	 * @param buyProduct
	 *            product bought by the caller agent from this cell; <i>must be
	 *            non-negative and below the current
	 *            <code>productAvailability</code></i>
	 */
	public void productBought(final double buyProduct) {
		if (buyProduct < 0.0) {
			throw new IllegalArgumentException(String.format(
					"buyProduct = %f < 0.0", buyProduct));
		}

		if (buyProduct > productAvailability) {
			throw new IllegalArgumentException(String.format(
					"buyProduct = %f > productAvailability = %f", buyProduct,
					productAvailability));
		}
		productAvailability -= buyProduct;
	}
/*
 * Hashmap to store all the reviewers ids and ratings for individual product cell
 */
	public  Map<String, Double> toRatingSystem(){
		final Grid<Object> grid = SMUtils.getGrid(this);
		final GridPoint location = grid.getLocation(this);
		final Iterable<Object> objects = grid.getObjectsAt(location.getX(),
				location.getY());

		for (Object o : objects) {
			if (o instanceof Reviewer) {
				final Reviewer review = (Reviewer) o;
			    name = review.getID();
			    value = review.getRate();
			    value = SMUtils.round(value, 2);
			    rvrLoc = review.location;
				double diffInRate = fixedProductRating() - value;
				diffInRate = SMUtils.round(diffInRate, 2);
				//ratingSystem.put(name, value);
				fullRatingSystem.put(name, value);
				diffInRatingSystem.put(name, diffInRate);

			
			}	
			else if (o instanceof PositiveReviewer) {
					final PositiveReviewer reviewPos = (PositiveReviewer) o;
					String name = reviewPos.getID();
					value = reviewPos.getRate();
					value = SMUtils.round(value, 2);
					double diffInRate =  value - fixedProductRating() ;
					diffInRate = SMUtils.round(diffInRate, 2);
					//ratingSystem.put(name, value);
					fullRatingSystem.put(name, value);
					diffInRatingSystem.put(name, diffInRate);
			
			}	else if (o instanceof NegativeReviewer) {
				final NegativeReviewer reviewNeg = (NegativeReviewer) o;
				String name = reviewNeg.getID();
				value = reviewNeg.getRate();
				value = SMUtils.round(value, 2);
				double diffInRate = fixedProductRating() - value;
				diffInRate = SMUtils.round(diffInRate, 2);
			//	ratingSystem.put(name, value);
				fullRatingSystem.put(name, value);
				diffInRatingSystem.put(name, diffInRate);
		}
     }        
	/*	for (Map.Entry<String, Double> entry : diffInRatingSystem.entrySet())
		{
			lowest = SMUtils.round(lowest, 2);
			lowest = Collections.min(ratingSystem.values());

			if (lowest < 0)
			{   
				Math.abs(lowest);
			}
			
			highest = SMUtils.round(highest, 2);
		    highest = Collections.max(ratingSystem.values());

			rangeBetween = highest - lowest;
			rangeBetween = SMUtils.round(rangeBetween, 2);
		} 
		*/
		  //Commented out to test reviewer map 19.02 9.40pm
		//	System.out.println(" @ "+location+" "+entry.getKey() + "/" + df.format(entry.getValue()) +" lowestVal "+ lowest
			//			+ " highestVal " + highest+" range between low & high "+rangeBetween/*+ cannot use to string with this as it produces a different rate " && "+ toString()*/);
		      //   double minIndex = Collections.min(diffInRatingSystem.values());
		
	  // System.out.println("@"+location+" " + fullRatingSystem/*+" ProductRate : " + fixedProductRating()*/);
		//	System.out.println("@"+location+" " + diffInRatingSystem + " Low rate:" + lowest+ " High rate:"+highest+" Range: "+ rangeBetween /*+ lowest()*/);

			return fullRatingSystem;	//return locationRatingSystem; // return ratingSystem;         //	return reviewRatingSystem;       
		}

     public double fixedProductRating(){
 		productCellFixedRating = 5;// RandomHelper.nextDoubleFromTo(0.0,10);
 		return productCellFixedRating;
     }
	@Override
	public String toString() {
		// Override default Java implementation just to have a nicer
		// representation
		return String.format("ProductCell @ location (%d, %d), rating = %.2f ,cellValue = %.2f",
				x, y, getRating(),cellValue);
	}
}
