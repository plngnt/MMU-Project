package reviewmodel.agents;

import java.util.List;
import java.util.Random;

import reviewmodel.common.Constants;
import reviewmodel.common.SMUtils;
import repast.simphony.engine.environment.RunEnvironment;
import repast.simphony.engine.schedule.ScheduledMethod;
import repast.simphony.parameter.Parameter;
import repast.simphony.parameter.Parameters;
import repast.simphony.query.space.grid.GridCell;
import repast.simphony.query.space.grid.GridCellNgh;
import repast.simphony.random.RandomHelper;
import repast.simphony.space.grid.Grid;
import repast.simphony.space.grid.GridPoint;
import repast.simphony.util.ContextUtils;
import repast.simphony.util.SimUtilities;


public class PositiveReviewer {

	
	private double size = 1.0;
	private double maxConsumptionRate = 1.0;
	private double rate = 0.0 ;
	private double difference;
	private String Id;
	private String AB = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	private Random rnd = new Random();

	public PositiveReviewer() {
		super();
		createID(5);
	}

	public String getID() {
		return Id;
	}

	public void setID(String id) {
		this.Id = id;
	}
   @Parameter(displayName = "Positivity Level", usageName = "positivityLevel")
	public double getRate() {
		return rate;
	}
	public void setRate(double rate) {
		this.rate = rate; 
	}
	
	public double getDifference() {
		return difference;
	}

	public void setDifference(double difference) {
		this.difference = difference;
	}

	public double getSize() {
		return size;
	}

	public void setSize(final double size) {
		this.size = size;
	}

    final Parameters parameters = RunEnvironment.getInstance()
           .getParameters();

	/*
	 * Give each reviewer agent a unique id
	 */
	public synchronized String createID(int len) {
		StringBuilder sb = new StringBuilder(len);
		for (int i = 0; i < len; i++)
			sb.append(AB.charAt(rnd.nextInt(AB.length())));
		Id = ("Pos:" + sb.toString());
		return Id;
	}

	public Grid<Object> getGrid() {
		@SuppressWarnings("unchecked")
		final Grid<Object> grid = (Grid<Object>) ContextUtils.getContext(this)
				.getProjection(Constants.GRID_ID);

		if (null == grid) {
			throw new IllegalStateException("Cannot locate grid in context.");
		}

		return grid;
	}
	/**
	 * Implementation of the agent activity in each turn.
	 * 
	 * <p>
	 * Using the annotation {@link ScheduledMethod} makes this
	 * <code>step()</code> method executed from the first simulation tick, and
	 * with specifying interval it is executed each tick afterwards.
	 * </p>
	 * 
	 * <p>
	 * Agents work in a very simple way: they gather their neighbourhood and
	 * check for empty locations. If any is found, one of them is randomly
	 * chosen and the agent is relocated to that location.
	 * </p>
	 */
	@ScheduledMethod(start = 1, interval = 1, priority = 0)
	public void step() {
		// Reference for the used grid
				final Grid<Object> grid = SMUtils.getGrid(this);

				// Get the grid location of this Positive Reviewer
				final GridPoint location = grid.getLocation(this);
				
		// We use the GridCellNgh class to create GridCells for the surrounding
		// neighborhood. It contains the locations, and a list of objects from
		// the specified class which is accessible from that location

		final List<GridCell<PositiveReviewer>> PosReviewerNeighborhood = new GridCellNgh<PositiveReviewer>(
				getGrid(), location, PositiveReviewer.class, Constants.REVIEWER_VISION_RANGE,
				Constants.REVIEWER_VISION_RANGE).getNeighborhood(false);

		// We have a utility function that returns the filtered list of empty
		// GridCells objects
		final List<GridCell<PositiveReviewer>> freeCells = SMUtils
				.getFreeGridCells(PosReviewerNeighborhood);

		// Model specifies if there is no empty location in vision range, the
		// PositiveReviewer agent cannot move
		if (freeCells.isEmpty()) {
			return;
		}

		// CHECKME Is it needed?
		SimUtilities.shuffle(freeCells, RandomHelper.getUniform());

		// Get a random free location within sight range
		final GridCell<PositiveReviewer> chosenFreeCell = SMUtils.randomElementOf(freeCells);

		// We have our new GridPoint to move to, so relocate agent
		final GridPoint newGridPoint = chosenFreeCell.getPoint();
		getGrid().moveTo(this, newGridPoint.getX(), newGridPoint.getY());
	}

	/**
	 * Each time step, a PositiveReviewer grows by a fixed amount, <code>1.0</code>, and this
	 * action is scheduled after the <code>move()</code> action.
	 */
	@ScheduledMethod(start = 1, interval = 1, priority = -1)
	public void grow() {
		size += productConsumption() ;
	}
/*	working but commented out as the product rate changed with each time step using fixed value of 5 in product
 * cell method fixedProductRating()
	 * get product cell rating
	 
	public ProductCell productRate() {
		final Grid<Object> grid = SMUtils.getGrid(this);
		final GridPoint location = grid.getLocation(this);
		final Iterable<Object> objects = grid.getObjectsAt(location.getX(),
				location.getY());

		ProductCell productRate = null;
		for (Object o : objects) {
			if (o instanceof ProductCell) {
				productRate = (ProductCell) o;
		    }
		}
		return productRate;
	}*/
	private double productConsumption() {

		final ProductCell cell = getUnderlyingCell();
		final double productAvailable = cell.getProductAvailability();
	//	double productRating = cell.getRating();
       
		final double posProdRate = /*productRating
				+ */((Double) parameters
						.getValue(Constants.PARAMETER_ID_POSITIVITY_LEVEL))
						.doubleValue();
		
        final double buyProduct = Math.min(maxConsumptionRate, productAvailable);
		cell.productBought(buyProduct);
	
		rate = RandomHelper.nextDoubleFromTo(Constants.PRODUCT_FIXED_RATE, posProdRate);
	    if(rate < 5.0){
	      rate = 5.0;
	    }
	    if(rate > 10.0) {
	    	rate = 10.0;
	    }
	    difference = rate - Constants.PRODUCT_FIXED_RATE;
	    rate = SMUtils.round(rate, 2);
	    difference = SMUtils.round(difference, 2);
		assert (buyProduct >= 0) : String.format(
				"Derived productRandValue of buyProduct = %f should be >=0.", buyProduct);
		assert (buyProduct <= maxConsumptionRate);
		assert (buyProduct <= productAvailable);

		return buyProduct;
	}
	
	private ProductCell getUnderlyingCell() {
		final Grid<Object> grid = SMUtils.getGrid(this);
		final GridPoint location = grid.getLocation(this);
		final Iterable<Object> objects = grid.getObjectsAt(location.getX(),
				location.getY());

		ProductCell ret = null;

		for (final Object object : objects) {
			if (object instanceof ProductCell) {
				final ProductCell cell = (ProductCell) object;
				 if (ret != null) {
					throw new IllegalStateException(
							String.format(
									"Multiple cells defined for the same position;cell 1=%s, cell 2=%s",
									ret, cell));
				}
				ret = cell;
			}
		}
		if (null == ret) {
			throw new IllegalStateException(String.format(
					"Cannot find any cells for location %s", location));
		}
		return ret;
	}	
	
	@Override
	public String toString() {
		// Get grid location of Positive reviewer
		final String location = (ContextUtils.getContext(this) != null) ? getGrid()
				.getLocation(this).toString() : "[?, ?]";

		// Override default Java implementation just to have a nicer
        return String.format("PositiveReviewer  @ location %s, rating = %.2f",  location, rate);
        
	}

}
