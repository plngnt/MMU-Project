package reviewmodel.agents;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Random;
import java.util.Set;

import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.Multimap;
import com.jgoodies.common.base.Objects;
import com.sun.media.jfxmedia.logging.Logger;

import repast.simphony.engine.schedule.ScheduledMethod;
import repast.simphony.query.space.grid.GridCell;
import repast.simphony.query.space.grid.GridCellNgh;
import repast.simphony.random.RandomHelper;
import repast.simphony.space.grid.Grid;
import repast.simphony.space.grid.GridPoint;
import repast.simphony.util.ContextUtils;
import repast.simphony.util.SimUtilities;
import reviewmodel.common.Constants;
import reviewmodel.common.SMUtils;
import reviewmodel.output.CoverageCounter;

public class Watcher {
	private double size = 1.0;
	private double rate = 0.0;
	private double lowRate, highRate, sum;
	private int counter = 0;
	private String Id, keyId;
	private String AB = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
	private Random rnd = new Random();
	static Multimap<String, Double> previousRatings = ArrayListMultimap.create();
	static Map<String, Double> reviewMap = new HashMap<String, Double>();
	static Map<String, Double> reviewMapAverage = new HashMap<String, Double>();
	//static Map<String, Double> reviewMapPosId = new HashMap<String, Double>();
	private ProductCell cellReviews;

	public Watcher() {
		super();
		createID(5);
	}

	public String getID() {
		return Id;
	}

	public void setID(String id) {
		this.Id = id;
	}

	public double getRate() {
		return rate;
	}

	public void setRate(double rate) {
		this.rate = rate;
	}

	public double getSize() {
		return size;
	}

	public void setSize(final double size) {
		this.size = size;
	}
/*	public Map<String, Double> getReviewMapAverage() {
		return reviewMapAverage;
	}*/
/*	public static Map<String, Double> getReviewMapPosId() {
		return reviewMapPosId;
	}
*/
	/*
	 * Give each watcher agent a unique id
	 */
	public synchronized String createID(int len) {
		StringBuilder sb = new StringBuilder(len);
		for (int i = 0; i < len; i++)
			sb.append(AB.charAt(rnd.nextInt(AB.length())));
		Id = ("Watcher ID : " + sb.toString());
		return Id;
	}

	public Grid<Object> getGrid() {
		@SuppressWarnings("unchecked")
		final Grid<Object> grid = (Grid<Object>) ContextUtils.getContext(this)
				.getProjection(Constants.GRID_ID);

		if (null == grid) {
			throw new IllegalStateException("Cannot locate grid in context.");
		}

		return grid;
	}

	/**
	 * Implementation of the agent activity in each turn.
	 * 
	 * <p>
	 * Using the annotation {@link ScheduledMethod} makes this
	 * <code>step()</code> method executed from the first simulation tick, and
	 * with specifying interval it is executed each tick afterwards.
	 * </p>
	 * 
	 * <p>
	 * Agents work in a very simple way: they gather their neighbourhood and
	 * check for empty locations. If any is found, one of them is randomly
	 * chosen and the agent is relocated to that location.
	 * </p>
	 */
	@ScheduledMethod(start = 3, interval = 1, priority = 0)
	public void step() {
		// Reference for the used grid
		final Grid<Object> grid = SMUtils.getGrid(this);
		// Get the grid location of this Bug
		final GridPoint location = grid.getLocation(this);

		// We use the GridCellNgh class to create GridCells for the surrounding
		// Neighbourhood. It contains the locations, and a list of objects from
		// the specified class which is accessible from that location

		final List<GridCell<Watcher>> WatcherNeighborhood = new GridCellNgh<Watcher>(
				getGrid(), location, Watcher.class,
				Constants.REVIEWER_VISION_RANGE,
				Constants.REVIEWER_VISION_RANGE).getNeighborhood(false);

		// We have a utility function that returns the filtered list of empty
		// GridCells objects
		final List<GridCell<Watcher>> freeCells = SMUtils
				.getFreeGridCells(WatcherNeighborhood);

		// Model specifies if there is no empty location in vision range, the
		// Watcher agent cannot move
		if (freeCells.isEmpty()) {
			return;
		}

		// CHECKME Is it needed?
		SimUtilities.shuffle(freeCells, RandomHelper.getUniform());

		// Get a random free location within sight range
		final GridCell<Watcher> chosenFreeCell = SMUtils
				.randomElementOf(freeCells);

		// We have our new GridPoint to move to, so relocate agent
		final GridPoint newGridPoint = chosenFreeCell.getPoint();
		getGrid().moveTo(this, newGridPoint.getX(), newGridPoint.getY());
	}

	private ProductCell getUnderlyingCell() {
		final Grid<Object> grid = SMUtils.getGrid(this);
		final GridPoint location = grid.getLocation(this);
		final Iterable<Object> objects = grid.getObjectsAt(location.getX(),
				location.getY());

		ProductCell ret = null;

		for (final Object object : objects) {
			if (object instanceof ProductCell) {
				final ProductCell cell = (ProductCell) object;
				if (ret != null) {

					throw new IllegalStateException(
							String.format(
									"Multiple cells defined for the same position;cell 1=%s, cell 2=%s",
									ret, cell));
				}
				ret = cell;
			}
		}
		if (null == ret) {
			throw new IllegalStateException(String.format(
					"Cannot find any cells for location %s", location));
		}
		return ret;
	}

	//@SuppressWarnings("null")
	public Multimap<String,Double>readPastRatings(){
		 CoverageCounter cCReviews = new CoverageCounter();
		previousRatings = cCReviews.getMyMultimap();
		Set<String> keys = reviewMapAverage.keySet();
		for (String key : keys) {
			System.out.println("Key = " + key);
			System.out.println("Diff in revMap Values = " + reviewMapAverage.get(key) + "\n");
		}	
		return previousRatings;
	}
	
	public Map<String,Double>convertToHashMap() {
		
		reviewMapAverage = cellReviews.getFullRatingSystem();
		return reviewMapAverage;
	}
	
	public Map<String, Double> readReview() {
		final ProductCell cellReviews = getUnderlyingCell();
		reviewMap = cellReviews.getFullRatingSystem();

		return reviewMap;
     
	}

	public double highest() {
		for (Map.Entry<String, Double> entry : reviewMap.entrySet()) {
			highRate = Collections.max(reviewMap.values());
		}
		return highRate;
	}

	public double lowest() {
		for (Map.Entry<String, Double> entry : reviewMap.entrySet()) {
			lowRate = Collections.min(reviewMap.values());
		}
		return lowRate;
	}
	
    public Map<String, Double> calculateAverage() {
    	Map<String, Double> newMap = new HashMap<String, Double>();
    	List<Double> averList = new ArrayList<Double>(previousRatings.values());
    	List<Double> averagesList = new ArrayList<Double>(previousRatings.values());
    	double average;
    	for(Map.Entry<String, Double>entry : previousRatings.entries()){
    		//
    		 
    		averList.add(new Double(entry.getValue()));
    		keyId = entry.getKey();
    	}

           for(Double d : averagesList) {
        	 System.out.println(d +"   averagesList");
           }
          for (double val : averList){
 
        	  sum += val;
        	 counter++;
          } 
    	average = sum/counter;
    	average = SMUtils.round(average, 2);
    	newMap.put(keyId, average);
    	System.out.println("Average Map " + newMap);
    	System.out.println("averagesList in calculate average meth in watcher >> "+ averagesList);
		return newMap;
    }
/*	public Collection<Double> pastRates() {
		Collection<Double> value = null;
	      for (Entry<String, Double> entry : previousRatings.entries()) {
	         String key = entry.getKey();
	        value =  previousRatings.get(getHighestName());
	         System.out.println(key + "::" + value);
	      }
			return value;
			}*/
	public String getHighestName() {
		for (Map.Entry<String, Double> entry : reviewMap.entrySet()) {
			if (Objects.equals(highRate, entry.getValue())) {
				return entry.getKey();
			}
		}
		return null;
	}

	public String getLowestName() {
		for (Map.Entry<String, Double> entry : reviewMap.entrySet()) {
			if (Objects.equals(lowRate, entry.getValue())) {
				return entry.getKey();
			}
		}
		return null;
	}
  
	public String  readPastLowReviews() {
		String lName = getLowestName();
	      /*List<Double> lowerList = (List<Double>)previousRatings.get(getLowestName());
	      System.out.println(lowerList.toString());*/
	/*	Set<String>keys = previousRatings.keySet();
		
		for (String key : keys) {
			if(previousRatings.containsKey(lName))
		     System.out.println("Low Name Key = " + lName);
		     System.out.println("Low Name Values = " + previousRatings.get(lName) +"\n");
		     System.out.println(previousRatings.asMap());
		}
*/         return lName;
		//return lowerList;
	}

	public String readPastHighReviews() {
		
		String hName = getHighestName();
		return  hName; // 
	}


	public String location() {
		final String location = (ContextUtils.getContext(this) != null) ? getGrid()
				.getLocation(this).toString() : "[?, ?]";
		/*
		 * return String.format("Watcher  @ location %s,  rating = %.2f",
		 * location, rate);
		 */
		return location;
	}

	@Override
	public String toString() {
		// Get grid location of Watcher
		final String location = (ContextUtils.getContext(this) != null) ? getGrid()
				.getLocation(this).toString() : "[?, ?]";

		return String
				.format("Watcher  @ location %s, size=%.2f, rating = %.2f, highRate = ",
						location, size, rate, highRate);

	}

}
