package reviewmodel.agents;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.Multimap;

import reviewmodel.common.Constants;
import reviewmodel.common.SMUtils;
import repast.simphony.engine.environment.RunEnvironment;
import repast.simphony.engine.schedule.ScheduledMethod;
import repast.simphony.parameter.Parameters;
import repast.simphony.query.space.grid.GridCell;
import repast.simphony.query.space.grid.GridCellNgh;
import repast.simphony.random.RandomHelper;
import repast.simphony.space.grid.Grid;
import repast.simphony.space.grid.GridPoint;
import repast.simphony.util.ContextUtils;
import repast.simphony.util.SimUtilities;

public class Reviewer {

	private double size = 1.0;
	private double maxConsumptionRate = 1.0;
	private double rate = 0.0;
	private double difference;
	private String Id;
	private String AB = "0123456789";
	private Random rnd = new Random();
	List<Double> storeReviewRating = new ArrayList<Double>();
	List<Double> storeProductRating = new ArrayList<Double>();
	//List<Double> previous = new ArrayList<Double>();
    Multimap<Double, Double> multiMapPrevious = ArrayListMultimap.create();
	Map<String, Double> reviewersStoredRatings = new HashMap<String, Double>();
	//DecimalFormat df = new DecimalFormat("#0.00");
	final String location = null;

	public Reviewer() {
		super();
		createID(5);
	//getPrevious();
		// location();
		// toReviewersStoredRating();
	}

/*	public Map<String, Double> getReviewersStoredRatings() {
		return reviewersStoredRatings;
	}

	public void setReviewersStoredRatings(
			Map<String, Double> reviewersStoredRatings) {
		this.reviewersStoredRatings = reviewersStoredRatings;
	}
*/
	public String getID() {
		return Id;
	}

	public void setID(String id) {
		this.Id = id;
	}

	public double getRate() {
		return rate;
	}

	public void setRate(double rate) {
		this.rate = rate;
	}

	public double getSize() {
		return size;
	}

	public void setSize(final double size) {
		this.size = size;
	}
	public double getDifference() {
		return difference;
	}

	public void setDifference(double difference) {
		this.difference = difference;
	}
/*	public Multimap<Double, Double> getPrevious() {
		return multiMapPrevious;		
	}*/
	// get environment variables from GUI
	final Parameters parameters = RunEnvironment.getInstance().getParameters();
	final int reviewerCount = ((Integer) parameters
			.getValue(Constants.PARAMETER_ID_REVIEWER_COUNT)).intValue();

	/*
	 * Give each reviewer agent a unique id
	 */
	public synchronized String createID(int len) {
		StringBuilder sb = new StringBuilder(len);
		for (int i = 0; i < len; i++)
			sb.append(AB.charAt(rnd.nextInt(AB.length())));
		Id = ("Rvr:" + sb.toString());
		return Id;
	}

	/*
	 * Returns a reference to the grid on which the agent is located at.
	 */
	public Grid<Object> getGrid() {
		@SuppressWarnings("unchecked")
		final Grid<Object> grid = (Grid<Object>) ContextUtils.getContext(this)
				.getProjection(Constants.GRID_ID);
		if (null == grid) {
			throw new IllegalStateException("Cannot locate grid in context.");
		}
		return grid;
	}

	/*
	 * Implementation of the agent activity in each turn.
	 * 
	 * <p> Using the annotation {@link ScheduledMethod} makes this
	 * <code>step()</code> method executed from the first simulation tick, and
	 * with specifying interval it is executed each tick afterwards. </p>
	 * 
	 * <p> Agents work in a very simple way: they gather their neighbourhood and
	 * check for empty locations. If any is found, one of them is randomly
	 * chosen and the agent is relocated to that location. </p>
	 */
	@ScheduledMethod(start = 1, interval = 1, priority = 0)
	public void step() {
		// Reference for the used grid
		final Grid<Object> grid = SMUtils.getGrid(this);
		// Get the grid location of this Bug
		final GridPoint location = grid.getLocation(this);

		// We use the GridCellNgh class to create GridCells for the surrounding
		// Neighbourhood. It contains the locations, and a list of objects from
		// the specified class which is accessible from that location

		final List<GridCell<Reviewer>> ReviewerNeighborhood = new GridCellNgh<Reviewer>(
				getGrid(), location, Reviewer.class,
				Constants.REVIEWER_VISION_RANGE,
				Constants.REVIEWER_VISION_RANGE).getNeighborhood(false);

		// We have a utility function that returns the filtered list of empty
		// GridCells objects
		final List<GridCell<Reviewer>> freeCells = SMUtils
				.getFreeGridCells(ReviewerNeighborhood);

		// Model specifies if there is no empty location in vision range, the
		// Reviewer agent cannot move
		if (freeCells.isEmpty()) {
			return;
		}

		// CHECKME Is it needed?
		SimUtilities.shuffle(freeCells, RandomHelper.getUniform());

		// Get a random free location within sight range
		final GridCell<Reviewer> chosenFreeCell = SMUtils
				.randomElementOf(freeCells);

		// We have our new GridPoint to move to, so relocate agent
		final GridPoint newGridPoint = chosenFreeCell.getPoint();
		getGrid().moveTo(this, newGridPoint.getX(), newGridPoint.getY());
	}

	/*
	 * Each time step, a Reviewer grows by a fixed amount, <code>1.0</code>, and
	 * this action is scheduled after the <code>move()</code> action.
	 */
	@ScheduledMethod(start = 1, interval = 1, priority = -1)
	public void grow() {
		size += productConsumption();
	}

/* working but commented out as the product rate changed with each time step
	 * get product cell rating
	 
	public ProductCell productRate() {
		final Grid<Object> grid = SMUtils.getGrid(this);
		final GridPoint location = grid.getLocation(this);
		final Iterable<Object> objects = grid.getObjectsAt(location.getX(),
				location.getY());

		ProductCell productRate = null;
		for (Object o : objects) {
			if (o instanceof ProductCell) {
				productRate = (ProductCell) o;
			}
		}
		return productRate;
	}

	public ProductCell globalProdRating() {
		final ProductCell globalProdRating = productRate();
		System.out
				.println("global prod rating does it match cCounter's prodrate  : "
						+ globalProdRating);
		return globalProdRating;
	}
*/
	private double productConsumption() {
		final ProductCell cell = getUnderlyingCell();
		final double productAvailable = cell.getProductAvailability();
		//final double productRating = cell.getRating();

		final double buyProduct = Math
				.min(maxConsumptionRate, productAvailable);
		cell.productBought(buyProduct);

		rate = RandomHelper.nextDoubleFromTo(Constants.PRODUCT_FIXED_RATE , Constants.PRODUCT_FIXED_RATE );
		if (rate < 1) {
			rate = 1.0;
		}
		if (rate > 10) {
			rate = 10.0;
		}
	    difference = rate - Constants.PRODUCT_FIXED_RATE;
	    rate = SMUtils.round(rate, 2);
	    difference = SMUtils.round(difference, 2);
		assert (buyProduct >= 0) : String.format(
				"Derived productRandValue of buyProduct = %f should be >=0.",
				buyProduct);
		assert (buyProduct <= maxConsumptionRate);
		assert (buyProduct <= productAvailable);

	/*	multiMapPrevious.put(rate, difference);*/
		
		
			return buyProduct;
	}
	
	/*
	 * public Map<String, Double> toReviewersStoredRating() { final Grid<Object>
	 * grid = SMUtils.getGrid(this); final GridPoint location =
	 * grid.getLocation(this); final Iterable<Object> objects =
	 * grid.getObjectsAt(location.getX(), location.getY());
	 * 
	 * ProductCell rateProduct = null; for (Object o : objects) { if (o
	 * instanceof ProductCell) { rateProduct = (ProductCell) o;
	 * reviewersStoredRatings.put(getID(), getRate()); } }
	 * 
	 * for (Map.Entry<String, Double> entry : reviewersStoredRatings.entrySet())
	 * { System.out.println(entry.getKey() + "//" + df.format(entry.getValue())+
	 * location()); } return reviewersStoredRatings; }
	 */

	// Original random rating for product commented out
	/*
	 * public double rateProduct(){ double rateProduct = productConsumption();
	 * DecimalFormat df = new DecimalFormat("#.00"); rateMark =
	 * RandomHelper.nextDoubleFromTo(Constants.REVIEWER_LOWEST_MARK,
	 * Constants.REVIEWER_HIGHEST_MARK); df.format(rateMark); rated = rateMark;
	 * df.format(rated); return rateProduct; }
	 */

	private ProductCell getUnderlyingCell() {
		final Grid<Object> grid = SMUtils.getGrid(this);
		final GridPoint location = grid.getLocation(this);
		final Iterable<Object> objects = grid.getObjectsAt(location.getX(),
				location.getY());

		ProductCell ret = null;

		for (final Object object : objects) {
			if (object instanceof ProductCell) {
				final ProductCell cell = (ProductCell) object;
				if (ret != null) {
					throw new IllegalStateException(
							String.format(
									"Multiple cells defined for the same position;cell 1=%s, cell 2=%s",
									ret, cell));
				}
				ret = cell;
			}
		}
		if (null == ret) {
			throw new IllegalStateException(String.format(
					"Cannot find any cells for location %s", location));
		}
		return ret;
	}
    
	public String location() {
		final String location = (ContextUtils.getContext(this) != null) ? getGrid()
				.getLocation(this).toString() : "[?, ?]";
		/*return String.format("Rwr @ %s, rating = %.2f",
				location, rate);*/
				return location;
	}

	@Override
	public String toString() {
		// Get grid location of Reviewer
		final String location = (ContextUtils.getContext(this) != null) ? getGrid()
				.getLocation(this).toString() : "[?, ?]";

		return String.format(
				"Reviewer  @ location %s, size=%.2f, rating = %.2f", location,
				size, rate);
		/*return String.format("Reviewer  @ location %s, Id %s,  rating = %.2f",
				location, Id, rate);*/
	}
}
